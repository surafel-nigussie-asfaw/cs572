import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-smart></app-smart>
  `
})
export class AppComponent {
  title = 'app works!';
}
