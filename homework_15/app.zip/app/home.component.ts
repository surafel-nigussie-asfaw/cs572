import { Component } from '@angular/core';


@Component({
  selector: 'home',
  template: `
        Homepage
  `
})
export class HomeComponent {
}