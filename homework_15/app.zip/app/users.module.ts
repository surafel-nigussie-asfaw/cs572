import { NgModule } from "@angular/core";
import { UsersComponent } from './users.component';
import { CommonModule } from '@angular/common';
import { UserDetailsComponent } from './user-details.component';

@NgModule({
  declarations: [UsersComponent, UserDetailsComponent],
  imports: [
    CommonModule
  ],
  bootstrap: [UsersComponent]
})
export class UsersModule {

} 