import { Component } from '@angular/core';

import { DataService } from './data.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [DataService]
})
export class AppComponent {
  myForm: FormGroup;

  constructor(private dataService: DataService, private formBuilder: FormBuilder) {
    this.myForm = formBuilder.group({
      'name': formBuilder.group({
        'first': ['surafel nigussie', [Validators.required]],
        'last': ['asfaw', Validators.required]
      }),
      'email': ['sunigussie@mum.edu', [
        Validators.required
      ]],
      'password': ['', Validators.required],
      'confirmpassword': ['', Validators.required]
    });

    this.myForm.valueChanges.subscribe(
      (data: any) => console.log(data)
    );
  }

  onSubmit(): void {
    console.log('you submitted value:', this.myForm.value)
  }

  asyncEmailValidator(control: FormControl): Promise<any> | Observable<any> {
    const promise = new Promise<any>(
      (resolve, reject) => {
        setTimeout(() => {
          if (control.value === 'sunigussie@mum.edu') {
            resolve({ 'invalid': true });
          } else {
            resolve(null);
          }
        }, 3000);
      }
    );
    return promise;
  }

}