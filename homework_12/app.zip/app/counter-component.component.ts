import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-counter',
  template: `
    <button (click) = "decrement()"> - </button>

    {{counter}}

    <button (click) = "increment()"> + </button>
  `,
  styles: []
})
export class CounterComponentComponent {
  @Input() counter: number = 0;
  @Output() counterChange =  new EventEmitter();

  increment() {
    this.counter++;
    this.counterChange.emit(this.counter);
    return false;
  }

  decrement() {
    this.counter--;
    this.counterChange.emit(this.counter);
    return false;
  }
}
