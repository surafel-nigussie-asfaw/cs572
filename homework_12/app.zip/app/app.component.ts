import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <app-counter [counter] = "15" (counterChange) = "counterChanged($event)"></app-counter>

  <router-outlet></router-outlet>
  `
})
export class AppComponent {
  title = 'Counter';

  counterChanged(e) {
    console.log(e)
  }
}