import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <p>
      Welcome
    </p>
  `
})
export class HomeComponent {
}