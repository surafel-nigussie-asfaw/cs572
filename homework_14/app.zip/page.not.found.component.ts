import { Component } from '@angular/core';

@Component({
  selector: 'app-404',
  template: `
    <p>
     Page not found.
    </p>
  `
})
export class PageNotFoundComponent {
}