import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-details',
  template: `
    <p>
      user-details works!
    </p>
  `,
  styles: []
})
export class UserDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
