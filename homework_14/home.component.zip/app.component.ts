import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  template: `
  <h1>{{title}}</h1>
  <nav>
    <a [routerLink]="['home']">Home</a>
    <a [routerLink]="['users']">Users</a>
  </nav>
  <router-outlet></router-outlet>
  `,
  providers: [DataService]
})
export class AppComponent {
  title = 'HW14';

  constructor(private dataService: DataService) {
    dataService.getOnlineData()
      .then(console.log)
      .catch(console.log)
  }
}